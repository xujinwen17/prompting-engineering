# Prompt Engineering

The experiment is based on the [code](https://github.com/liujch1998/GKP) for our ACL 2022 paper, [Generated Knowledge Prompting for Commonsense Reasoning.](https://arxiv.org/abs/2110.08387)

## Generate Knowledge

Use `gpt3_generate_knowledge.py` to generate knowledge for a task dataset.
For example, to generate knowledge for the validation set of NumerSense, run
```
python knowledge/gpt3_generate_knowledge.py \
    --task numersense \
    --input_path data/numersense/validation.json \
    --output_path data/numersense/knowledge/knowledge_gpt3.validation.json \
    --prompt_path knowledge/prompts/numersense_prompt.txt
```
This will create a JSON file that contains the knowledge statements for each question in this dataset.

This step needs access to GPT-3.
For convenience, we provide the knowledge files that were produced by our method and were used in downstream evaluation.
These files are at `data/{task_name}/knowledge/knowledge_gpt3.{split_name}.{task_name}.json`

## Inference with Knowledge Prompting

Use `infer_numersense_t5.py` to run inference with the generated knowledge:
```
CUDA_VISIBLE_DEVICES=0 python inference/infer_numersense_t5.py \
    --model-type t5-base \
    --input-path data/numersense/knowledge/knowledge_gpt3.validation.json
```
where `--input-path` is the knowledge file we produced in the previous step at the `--output-path`.
This will create a JSON file that contains the inference results under `data/{task_name}/inference/`.

To get the baseline of the inference model (i.e. without using generated knowledge), use the standardized data file as `--input-path`:
```
CUDA_VISIBLE_DEVICES=0 python inference/infer_numersense_t5.py \
    --task numersense \
    --model-type t5-base \
    --input-path data/numersense/valiadation.json
```
