import openai
import pandas as pd
from tqdm import tqdm
import time
import json

with open('matact_dev.json','r') as f:
    data=json.load(f)

with open('examples.txt','r') as f:
    examples=f.read()


model_name = "text-babbage-001"
# 设置API密钥
api_key = "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"
openai.api_key = api_key

right_num=0
total_num=0
for i in tqdm(range(len(data))):

    question = data[i]['context'] + data[i]['query']
    answer = data[i]['answer']
    prompt = f"{examples}\n\nQuestion: {question}\nAnswer: {answer}\n\nPlease evaluate if the given answer is consistent with common sense. Respond only with 'Yes' or 'No'. For example, if the answer makes sense, respond with 'Yes'. If the answer doesn't make sense, respond with 'No':"

    response = openai.Completion.create(
        engine=model_name,
        prompt=prompt,
        max_tokens=10,
        temperature=0.3
    )
    res = response.choices[0].text.strip()


    if (res.find("Yes") != -1 or res.find("yes") != -1):
        if (data[i]['classify'] == "yes"):
            right_num += 1
    elif (res.find("No") != -1 or res.find("no") != -1):
        if (data[i]['classify'] == "no"):
            right_num += 1

    total_num += 1
    print("acc=" + str(right_num / total_num))
    time.sleep(0.2)
